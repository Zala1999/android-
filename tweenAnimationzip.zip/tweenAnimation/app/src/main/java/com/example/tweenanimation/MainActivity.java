package com.example.tweenanimation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    Spinner sp1;
    ImageView img1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp1 = (Spinner)findViewById(R.id.sp1);
        img1 = (ImageView)findViewById(R.id.imageView);

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i)
                {
                    case 0:
                        Animation an1 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim1);
                        img1.startAnimation(an1);
                        break;
                    case 1:
                        Animation an2 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate);
                        img1.startAnimation(an2);
                        break;
                    case 2:
                        Animation an3 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.scale);
                        img1.startAnimation(an3);
                        break;
                    case 3:
                        Animation an4 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.translate);
                        img1.startAnimation(an4);
                        break;
                    case 4:
                        Animation an5 = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.all);
                        img1.startAnimation(an5);
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}